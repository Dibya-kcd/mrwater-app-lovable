import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyCSWaP62jnr2IUNDzyDs4Jdu3l7PBumZrg",
  authDomain: "mrwater-8696d.firebaseapp.com",
  databaseURL: "https://mrwater-8696d-default-rtdb.firebaseio.com",
  projectId: "mrwater-8696d",
  storageBucket: "mrwater-8696d.firebasestorage.app",
  messagingSenderId: "29569871622",
  appId: "1:29569871622:web:c2999d9b8aae04d643f887"
};

const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
export const storage = getStorage(app);