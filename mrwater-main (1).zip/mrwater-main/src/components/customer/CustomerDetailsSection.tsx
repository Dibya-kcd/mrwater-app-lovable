
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Customer } from "@/types";
import { toast } from "@/hooks/use-toast";

interface CustomerDetailsSectionProps {
  customer: Customer;
  name: string;
  setName: (name: string) => void;
  address: string;
  setAddress: (address: string) => void;
  contactNumber: string;
  setContactNumber: (number: string) => void;
  groupId: string | undefined;
  setGroupId: (id: string) => void;
  paymentBalance: number;
  setPaymentBalance: (balance: number) => void;
  productJars: Record<string, number>;
  setProductJars: (jars: Record<string, number>) => void;
  groups: any[];
  products: any[];
  onSave: () => void;
}

export const CustomerDetailsSection = ({
  customer,
  name,
  setName,
  address,
  setAddress,
  contactNumber,
  setContactNumber,
  groupId,
  setGroupId,
  paymentBalance,
  setPaymentBalance,
  productJars,
  setProductJars,
  groups,
  products,
  onSave,
}: CustomerDetailsSectionProps) => {
  const handleJarCountChange = (productId: string, count: number) => {
    setProductJars(prev => ({
      ...prev,
      [productId]: count
    }));
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Customer Name</Label>
        <Input 
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="address">Address</Label>
        <Input 
          id="address"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="contactNumber">Contact Number</Label>
        <Input 
          id="contactNumber"
          value={contactNumber}
          onChange={(e) => setContactNumber(e.target.value)}
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="group">Group</Label>
        <Select value={groupId} onValueChange={setGroupId}>
          <SelectTrigger id="group">
            <SelectValue placeholder="Not assigned to a group" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">Not assigned</SelectItem>
            {groups.map(group => (
              <SelectItem key={group.id} value={group.id}>
                {group.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label>Payment Balance ($)</Label>
        <Input
          type="number"
          step="0.01"
          value={paymentBalance}
          onChange={(e) => setPaymentBalance(parseFloat(e.target.value) || 0)}
          className={paymentBalance < 0 ? "text-red-500" : "text-green-500"}
        />
      </div>
      
      <div className="space-y-2">
        <Label>Jars Currently Held</Label>
        <div className="space-y-3">
          {products.map(product => (
            <div key={product.id} className="flex items-center space-x-2">
              <Label htmlFor={`product-${product.id}`} className="w-1/2">
                {product.name}:
              </Label>
              <Input 
                id={`product-${product.id}`}
                type="number"
                min="0"
                value={productJars[product.id] || 0}
                onChange={(e) => handleJarCountChange(product.id, parseInt(e.target.value) || 0)}
                className="w-1/2"
              />
            </div>
          ))}
        </div>
      </div>

      <Button onClick={onSave} className="w-full">Save Changes</Button>
    </div>
  );
};
