
import React from 'react';
import { format } from 'date-fns';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useQuery } from '@tanstack/react-query';
import { supabase } from "@/integrations/supabase/client";

interface TransactionHistoryProps {
  customerId: string;
}

export function TransactionHistoryList({ customerId }: TransactionHistoryProps) {
  const { data: logs, isLoading } = useQuery({
    queryKey: ['transaction-history', customerId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('transaction_history_logs')
        .select('*')
        .eq('customer_id', customerId)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      return data;
    },
  });

  if (isLoading) {
    return <div>Loading transaction history...</div>;
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Action</TableHead>
            <TableHead>Changes</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {logs?.map((log) => (
            <TableRow key={log.id}>
              <TableCell>{format(new Date(log.created_at), 'PPpp')}</TableCell>
              <TableCell>
                <Badge variant="outline">
                  {log.entity_type}
                </Badge>
              </TableCell>
              <TableCell>
                <Badge variant={log.action === 'deleted' ? 'destructive' : 'secondary'}>
                  {log.action}
                </Badge>
              </TableCell>
              <TableCell>
                <pre className="text-xs whitespace-pre-wrap">
                  {JSON.stringify(log.changes, null, 2)}
                </pre>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
