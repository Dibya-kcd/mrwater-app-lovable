
import { useContext } from "react";
import { AppContext } from "@/context/AppContext";
import { DialogFooter } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import CustomerForm from "./CustomerForm";

interface AddCustomerDialogProps {
  onClose?: () => void;
}

const AddCustomerDialog = ({ onClose }: AddCustomerDialogProps) => {
  const { addCustomer } = useContext(AppContext);

  const handleSubmit = (data: any) => {
    addCustomer({
      name: data.name,
      contactNumber: data.phone,
      address: data.address,
      jarsHeld: {
        cool: data.initialCoolBalance,
        pet: data.initialPetBalance,
      },
      discountRate: data.discountRate,
      paymentBalance: 0,
      depositDate: data.depositDate.toISOString(),
      notes: data.notes,
    });

    toast({
      title: "Customer added",
      description: `${data.name} has been added to your customers`,
    });

    if (onClose) {
      onClose();
    }
  };

  return (
    <div className="py-4">
      <CustomerForm onSubmit={handleSubmit} />
    </div>
  );
};

export default AddCustomerDialog;
