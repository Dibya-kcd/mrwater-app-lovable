
import { useState, useContext, useEffect } from "react";
import { format } from "date-fns";
import { AppContext } from "@/context/AppContext";
import { Delivery, Collection, Payment, Product } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { Package, ArrowDown, CreditCard, Check } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface CustomerDailyEntryFormProps {
  customerId: string;
  customerName: string;
  date: Date;
  initialDelivery?: Delivery;
  initialCollection?: Collection;
  initialPayment?: Payment;
  products: Product[];
}

const CustomerDailyEntryForm = ({
  customerId,
  customerName,
  date,
  initialDelivery,
  initialCollection,
  initialPayment,
  products
}: CustomerDailyEntryFormProps) => {
  const {
    addDelivery,
    updateDelivery,
    addCollection,
    updateCollection,
    addPayment,
    updatePayment,
  } = useContext(AppContext);

  // Delivery form state
  const [coolDelivered, setCoolDelivered] = useState(0);
  const [petDelivered, setPetDelivered] = useState(0);
  const [hasDelivery, setHasDelivery] = useState(false);
  const [deliveryId, setDeliveryId] = useState<string | null>(null);

  // Collection form state
  const [coolReturned, setCoolReturned] = useState(0);
  const [petReturned, setPetReturned] = useState(0);
  const [collectionAmount, setCollectionAmount] = useState(0);
  const [hasCollection, setHasCollection] = useState(false);
  const [collectionId, setCollectionId] = useState<string | null>(null);

  // Payment form state
  const [paymentAmount, setPaymentAmount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'bank_transfer'>('cash');
  const [hasPayment, setHasPayment] = useState(false);
  const [paymentId, setPaymentId] = useState<string | null>(null);

  // Initialize state based on existing records
  useEffect(() => {
    if (initialDelivery) {
      setCoolDelivered(initialDelivery.jarsDelivered.cool);
      setPetDelivered(initialDelivery.jarsDelivered.pet);
      setHasDelivery(true);
      setDeliveryId(initialDelivery.id);
    } else {
      setCoolDelivered(0);
      setPetDelivered(0);
      setHasDelivery(false);
      setDeliveryId(null);
    }

    if (initialCollection) {
      setCoolReturned(initialCollection.jarsReturned.cool);
      setPetReturned(initialCollection.jarsReturned.pet);
      setCollectionAmount(initialCollection.amount);
      setHasCollection(true);
      setCollectionId(initialCollection.id);
    } else {
      setCoolReturned(0);
      setPetReturned(0);
      setCollectionAmount(0);
      setHasCollection(false);
      setCollectionId(null);
    }

    if (initialPayment) {
      setPaymentAmount(initialPayment.amount);
      setPaymentMethod(initialPayment.paymentMethod);
      setHasPayment(true);
      setPaymentId(initialPayment.id);
    } else {
      setPaymentAmount(0);
      setPaymentMethod('cash');
      setHasPayment(false);
      setPaymentId(null);
    }
  }, [initialDelivery, initialCollection, initialPayment]);

  // Calculate collection amount based on product prices and quantity
  useEffect(() => {
    const coolProduct = products.find(p => p.type === 'Cool');
    const petProduct = products.find(p => p.type === 'PET');
    
    let amount = 0;
    if (coolProduct) {
      amount += coolDelivered * coolProduct.price;
    }
    if (petProduct) {
      amount += petDelivered * petProduct.price;
    }
    
    setCollectionAmount(amount);
  }, [coolDelivered, petDelivered, products]);

  const handleSaveDelivery = () => {
    const dateString = format(date, 'yyyy-MM-dd');
    
    if (hasDelivery && deliveryId) {
      updateDelivery(deliveryId, {
        jarsDelivered: {
          cool: coolDelivered,
          pet: petDelivered
        },
        status: 'completed'
      });
    } else {
      addDelivery({
        customerId,
        date: dateString,
        jarsDelivered: {
          cool: coolDelivered,
          pet: petDelivered
        },
        status: 'completed'
      });
    }
    
    toast({
      title: "Delivery saved",
      description: `Delivery for ${customerName} on ${format(date, 'PP')} has been recorded`,
    });
  };

  const handleSaveCollection = () => {
    const dateString = format(date, 'yyyy-MM-dd');
    
    if (hasCollection && collectionId) {
      updateCollection(collectionId, {
        jarsReturned: {
          cool: coolReturned,
          pet: petReturned
        },
        amount: collectionAmount,
        status: 'completed'
      });
    } else {
      addCollection({
        customerId,
        date: dateString,
        jarsReturned: {
          cool: coolReturned,
          pet: petReturned
        },
        amount: collectionAmount,
        status: 'completed'
      });
    }
    
    toast({
      title: "Collection saved",
      description: `Collection for ${customerName} on ${format(date, 'PP')} has been recorded`,
    });
  };

  const handleSavePayment = () => {
    const dateString = format(date, 'yyyy-MM-dd');
    
    if (hasPayment && paymentId) {
      updatePayment(paymentId, {
        amount: paymentAmount,
        paymentMethod,
        status: 'completed'
      });
    } else {
      addPayment({
        customerId,
        date: dateString,
        amount: paymentAmount,
        paymentMethod,
        status: 'completed'
      });
    }
    
    toast({
      title: "Payment saved",
      description: `Payment for ${customerName} on ${format(date, 'PP')} has been recorded`,
    });
  };

  const handleSaveAll = () => {
    if (coolDelivered > 0 || petDelivered > 0) {
      handleSaveDelivery();
    }
    
    if (coolReturned > 0 || petReturned > 0) {
      handleSaveCollection();
    }
    
    if (paymentAmount > 0) {
      handleSavePayment();
    }
    
    toast({
      title: "All entries saved",
      description: `All entries for ${customerName} on ${format(date, 'PP')} have been recorded`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Delivery section */}
        <div className="space-y-4 bg-muted/30 p-4 rounded-lg">
          <div className="flex items-center gap-2">
            <Package size={18} />
            <h3 className="text-lg font-medium">Delivery</h3>
          </div>
          
          <div className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="coolDelivered">Cool Jars Delivered</Label>
              <Input
                id="coolDelivered"
                type="number"
                min="0"
                value={coolDelivered}
                onChange={(e) => setCoolDelivered(parseInt(e.target.value) || 0)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="petDelivered">PET Jars Delivered</Label>
              <Input
                id="petDelivered"
                type="number"
                min="0"
                value={petDelivered}
                onChange={(e) => setPetDelivered(parseInt(e.target.value) || 0)}
              />
            </div>
            
            <Button
              onClick={handleSaveDelivery}
              disabled={coolDelivered === 0 && petDelivered === 0}
              className="w-full"
              size="sm"
            >
              {hasDelivery ? "Update Delivery" : "Save Delivery"}
            </Button>
          </div>
        </div>
        
        {/* Collection section */}
        <div className="space-y-4 bg-muted/30 p-4 rounded-lg">
          <div className="flex items-center gap-2">
            <ArrowDown size={18} />
            <h3 className="text-lg font-medium">Collection</h3>
          </div>
          
          <div className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="coolReturned">Cool Jars Returned</Label>
              <Input
                id="coolReturned"
                type="number"
                min="0"
                value={coolReturned}
                onChange={(e) => setCoolReturned(parseInt(e.target.value) || 0)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="petReturned">PET Jars Returned</Label>
              <Input
                id="petReturned"
                type="number"
                min="0"
                value={petReturned}
                onChange={(e) => setPetReturned(parseInt(e.target.value) || 0)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="collectionAmount">Amount (calculated)</Label>
              <Input
                id="collectionAmount"
                type="number"
                min="0"
                step="0.01"
                value={collectionAmount}
                onChange={(e) => setCollectionAmount(parseFloat(e.target.value) || 0)}
                className="bg-muted/50"
                readOnly
              />
            </div>
            
            <Button
              onClick={handleSaveCollection}
              disabled={coolReturned === 0 && petReturned === 0}
              className="w-full"
              size="sm"
            >
              {hasCollection ? "Update Collection" : "Save Collection"}
            </Button>
          </div>
        </div>
        
        {/* Payment section */}
        <div className="space-y-4 bg-muted/30 p-4 rounded-lg">
          <div className="flex items-center gap-2">
            <CreditCard size={18} />
            <h3 className="text-lg font-medium">Payment</h3>
          </div>
          
          <div className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="paymentAmount">Payment Amount</Label>
              <Input
                id="paymentAmount"
                type="number"
                min="0"
                step="0.01"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="paymentMethod">Payment Method</Label>
              <Select 
                value={paymentMethod} 
                onValueChange={(value) => setPaymentMethod(value as 'cash' | 'card' | 'bank_transfer')}
              >
                <SelectTrigger id="paymentMethod">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="card">Card</SelectItem>
                  <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button
              onClick={handleSavePayment}
              disabled={paymentAmount === 0}
              className="w-full"
              size="sm"
            >
              {hasPayment ? "Update Payment" : "Save Payment"}
            </Button>
          </div>
        </div>
      </div>
      
      <Separator />
      
      <Button 
        onClick={handleSaveAll} 
        className="w-full" 
        size="lg"
        disabled={(coolDelivered === 0 && petDelivered === 0) &&
                 (coolReturned === 0 && petReturned === 0) &&
                 (paymentAmount === 0)}
      >
        <Check className="mr-2" size={18} />
        Save All Entries
      </Button>
    </div>
  );
};

export default CustomerDailyEntryForm;
