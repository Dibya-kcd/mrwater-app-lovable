
import { useContext } from "react";
import { AppContext } from "@/context/AppContext";
import AppLayout from "@/components/layout/AppLayout";
import JarStatsCard from "@/components/inventory/JarStatsCard";
import CustomerJarSummary from "@/components/inventory/CustomerJarSummary";
import InventoryActions from "@/components/inventory/InventoryActions";
import JarFlowSummary from "@/components/inventory/JarFlowSummary";

const Inventory = () => {
  const { inventory, customers } = useContext(AppContext);

  // Calculate total jars with customers
  const totalJarsWithCustomers = customers.reduce(
    (total, customer) => {
      return {
        cool: total.cool + customer.jarsHeld.cool,
        pet: total.pet + customer.jarsHeld.pet,
      };
    },
    { cool: 0, pet: 0 }
  );

  return (
    <AppLayout>
      <div className="space-y-8">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Jar Inventory</h2>
          <p className="text-muted-foreground">
            Manage your jar inventory and track jars with customers
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <JarStatsCard 
            title="Cool Jars Available" 
            totalCount={inventory.cool + totalJarsWithCustomers.cool}
            availableCount={inventory.cool}
            color="#0EA5E9"
          />
          
          <JarStatsCard 
            title="PET Jars Available" 
            totalCount={inventory.pet + totalJarsWithCustomers.pet}
            availableCount={inventory.pet}
            color="#8B5CF6"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <JarFlowSummary 
            totalInventory={inventory} 
            totalJarsWithCustomers={totalJarsWithCustomers} 
          />
          
          <InventoryActions />
        </div>

        <div>
          <h3 className="text-xl font-bold tracking-tight mb-4">Customer Jar Holdings</h3>
          <CustomerJarSummary customers={customers} />
        </div>
      </div>
    </AppLayout>
  );
};

export default Inventory;
