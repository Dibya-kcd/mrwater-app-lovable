
import { useContext, useState } from "react";
import { AppContext } from "@/context/AppContext";
import AppLayout from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { DollarSign, Package, Pencil, Plus, Trash2 } from "lucide-react";
import { Product } from "@/types";

const Products = () => {
  const { products, addProduct, updateProduct, removeProduct } = useContext(AppContext);
  const [open, setOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<Product | null>(null);
  const [name, setName] = useState("");
  const [type, setType] = useState("");
  const [price, setPrice] = useState(0);
  const [description, setDescription] = useState("");
  const [inStock, setInStock] = useState(0);
  
  const resetForm = () => {
    setName("");
    setType("");
    setPrice(0);
    setDescription("");
    setInStock(0);
    setCurrentProduct(null);
    setEditMode(false);
  };
  
  const handleOpenDialog = (product?: Product) => {
    if (product) {
      setName(product.name);
      setType(product.type);
      setPrice(product.price);
      setDescription(product.description || "");
      setInStock(product.inStock);
      setCurrentProduct(product);
      setEditMode(true);
    } else {
      resetForm();
    }
    setOpen(true);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !type || price <= 0) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    const productData = {
      name,
      type,
      price,
      description,
      inStock,
    };
    
    if (editMode && currentProduct) {
      updateProduct(currentProduct.id, productData);
      toast({
        title: "Product updated",
        description: `${name} has been updated`,
      });
    } else {
      addProduct(productData);
      toast({
        title: "Product added",
        description: `${name} has been added to your products`,
      });
    }
    
    resetForm();
    setOpen(false);
  };
  
  const handleDelete = (id: string) => {
    removeProduct(id);
    toast({
      title: "Product removed",
      description: "The product has been removed from your list",
    });
  };
  
  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Products</h2>
            <p className="text-muted-foreground">
              Manage your products and their prices
            </p>
          </div>
          
          <Button onClick={() => handleOpenDialog()}>
            <Plus size={16} className="mr-2" />
            Add Product
          </Button>
        </div>
        
        {products.length === 0 ? (
          <div className="rounded-md bg-muted p-8 text-center">
            <Package size={48} className="mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No Products Added</h3>
            <p className="text-muted-foreground mb-4">
              Add your first product to get started
            </p>
            
            <Button onClick={() => handleOpenDialog()}>
              <Plus size={16} className="mr-2" />
              Add Product
            </Button>
          </div>
        ) : (
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>In Stock</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products.map(product => (
                  <TableRow key={product.id}>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell>{product.type}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <DollarSign size={16} />
                        {product.price.toFixed(2)}
                      </div>
                    </TableCell>
                    <TableCell>{product.inStock}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOpenDialog(product)}
                        >
                          <Pencil size={16} />
                          <span className="sr-only">Edit</span>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(product.id)}
                        >
                          <Trash2 size={16} />
                          <span className="sr-only">Delete</span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
        
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editMode ? "Edit Product" : "Add New Product"}</DialogTitle>
              <DialogDescription>
                {editMode
                  ? "Update the product details below"
                  : "Fill in the product details to add it to your list"}
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleSubmit}>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Product Name *</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g., Cool Water Jar"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="type">Product Type *</Label>
                  <Input
                    id="type"
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                    placeholder="e.g., Cool, PET, Mineral"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="price">Price ($) *</Label>
                  <Input
                    id="price"
                    type="number"
                    min="0.01"
                    step="0.01"
                    value={price}
                    onChange={(e) => setPrice(parseFloat(e.target.value) || 0)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Input
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Brief description of the product"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="inStock">In Stock</Label>
                  <Input
                    id="inStock"
                    type="number"
                    min="0"
                    value={inStock}
                    onChange={(e) => setInStock(parseInt(e.target.value) || 0)}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button type="submit">
                  {editMode ? "Update Product" : "Add Product"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
};

export default Products;
