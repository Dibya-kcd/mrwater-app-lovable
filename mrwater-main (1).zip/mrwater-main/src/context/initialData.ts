
import { Customer, Inventory, Group, Delivery, Collection, Payment, Product } from "@/types";

// Initial inventory state
export const initialInventory: Inventory = {
  cool: 200,
  pet: 150,
};

// Initial customers state
export const initialCustomers: Customer[] = [
  {
    id: "1",
    name: "Acme Corp",
    jarsHeld: {
      cool: 15,
      pet: 8,
    },
    address: "123 Business Ave, Enterprise City",
    contactNumber: "555-1234",
  },
  {
    id: "2",
    name: "Globex Industries",
    jarsHeld: {
      cool: 22,
      pet: 12,
    },
    address: "456 Commerce St, Trade Town",
    contactNumber: "555-5678",
    groupId: "1",
  },
  {
    id: "3",
    name: "Initech",
    jarsHeld: {
      cool: 10,
      pet: 15,
    },
    address: "789 Tech Blvd, Innovation City",
    contactNumber: "555-9012",
    groupId: "1",
  },
  {
    id: "4",
    name: "Massive Dynamic",
    jarsHeld: {
      cool: 30,
      pet: 20,
    },
    address: "321 Science Dr, Research Park",
    contactNumber: "555-3456",
    groupId: "2",
  },
  {
    id: "5",
    name: "Wayne Enterprises",
    jarsHeld: {
      cool: 5,
      pet: 10,
    },
    address: "987 Gotham Ave, Metropolitan City",
    contactNumber: "555-7890",
    groupId: "2",
  },
];

// Initial groups state
export const initialGroups: Group[] = [
  {
    id: "1",
    name: "Downtown Business District",
    description: "All businesses in the downtown area",
    collectionDay: "Monday",
    amountDue: 1500,
  },
  {
    id: "2",
    name: "Uptown Commercial Zone",
    description: "Commercial clients in the uptown district",
    collectionDay: "Wednesday",
    amountDue: 2200,
  },
];

// Initial deliveries state
export const initialDeliveries: Delivery[] = [
  {
    id: "1",
    customerId: "1",
    date: "2025-04-14",
    jarsDelivered: {
      cool: 5,
      pet: 3,
    },
    status: "completed",
  },
  {
    id: "2",
    customerId: "2",
    date: "2025-04-14",
    jarsDelivered: {
      cool: 8,
      pet: 5,
    },
    status: "completed",
  },
  {
    id: "3",
    customerId: "3",
    date: "2025-04-15",
    jarsDelivered: {
      cool: 3,
      pet: 2,
    },
    status: "pending",
  },
];

// Initial collections state
export const initialCollections: Collection[] = [
  {
    id: "1",
    customerId: "1",
    date: "2025-04-14",
    amount: 480,
    jarsReturned: {
      cool: 3,
      pet: 2,
    },
    status: "completed",
  },
  {
    id: "2",
    customerId: "2",
    date: "2025-04-14",
    amount: 650,
    jarsReturned: {
      cool: 5,
      pet: 3,
    },
    status: "completed",
  },
];

// Initial payments state
export const initialPayments: Payment[] = [
  {
    id: "1",
    customerId: "1",
    date: "2025-04-10",
    amount: 1200,
    paymentMethod: "card",
    status: "completed",
  },
  {
    id: "2",
    customerId: "2",
    date: "2025-04-12",
    amount: 850,
    paymentMethod: "cash",
    status: "completed",
  },
];

// Initial products state
export const initialProducts: Product[] = [
  {
    id: "1",
    name: "Cool Water Jar",
    type: "Cool",
    price: 25.99,
    description: "20L cool water jar",
    inStock: 200,
  },
  {
    id: "2",
    name: "PET Water Bottle",
    type: "PET",
    price: 15.50,
    description: "5L PET bottle",
    inStock: 150,
  },
  {
    id: "3",
    name: "Mineral Water Jar",
    type: "Mineral",
    price: 30.99,
    description: "20L mineral water jar",
    inStock: 100,
  },
];
