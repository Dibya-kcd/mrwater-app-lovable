
import { useState, useEffect } from "react";
import { Collection } from "@/types";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export function useCollections(updateJarInventory: (jars: { cool: number; pet: number }) => void) {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Fetch collections from Supabase
  useEffect(() => {
    const fetchCollections = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('collections')
          .select('*');

        if (error) {
          throw error;
        }

        if (data) {
          const formattedCollections: Collection[] = data.map((collection) => ({
            id: collection.id,
            customerId: collection.customer_id,
            date: collection.date,
            amount: collection.amount,
            jarsReturned: collection.jars_returned as { [productId: string]: number },
            status: collection.status as 'pending' | 'completed' | 'cancelled',
          }));

          setCollections(formattedCollections);
        }
      } catch (error: any) {
        console.error('Error fetching collections:', error.message);
        toast({
          title: "Error fetching collections",
          description: error.message,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchCollections();

    // Subscribe to changes in the collections table
    const subscription = supabase
      .channel('public:collections')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'collections' }, async () => {
        await fetchCollections();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [toast]);

  // Collection management functions
  const addCollection = async (collection: Omit<Collection, "id">) => {
    try {
      // Update Supabase
      const { data, error } = await supabase
        .from('collections')
        .insert([{
          customer_id: collection.customerId,
          date: collection.date,
          amount: collection.amount,
          jars_returned: collection.jarsReturned,
          status: collection.status,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const newCollection: Collection = {
          id: data.id,
          customerId: data.customer_id,
          date: data.date,
          amount: data.amount,
          jarsReturned: data.jars_returned as { [productId: string]: number },
          status: data.status as 'pending' | 'completed' | 'cancelled',
        };

        setCollections((prev) => [...prev, newCollection]);
      }
      
      // Update inventory only if collection is completed
      if (collection.status === "completed") {
        // Add jars back to inventory
        updateJarInventory({
          cool: collection.jarsReturned.cool || 0,
          pet: collection.jarsReturned.pet || 0,
        });
        
        // Update customer's jars held
        await updateCustomerJars(collection.customerId, collection.jarsReturned, false);
      }
    } catch (error: any) {
      console.error('Error adding collection:', error.message);
      toast({
        title: "Error adding collection",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const updateCollection = async (id: string, collection: Partial<Collection>) => {
    try {
      const oldCollection = collections.find(c => c.id === id);
      if (!oldCollection) throw new Error("Collection not found");
      
      // Convert from client model to database model
      const dbCollection: any = {};
      if (collection.customerId !== undefined) dbCollection.customer_id = collection.customerId;
      if (collection.date !== undefined) dbCollection.date = collection.date;
      if (collection.amount !== undefined) dbCollection.amount = collection.amount;
      if (collection.jarsReturned !== undefined) dbCollection.jars_returned = collection.jarsReturned;
      if (collection.status !== undefined) dbCollection.status = collection.status;
      dbCollection.updated_at = new Date().toISOString();

      const { error } = await supabase
        .from('collections')
        .update(dbCollection)
        .eq('id', id);

      if (error) throw error;

      // Update local state
      setCollections((prev) =>
        prev.map((c) => (c.id === id ? { ...c, ...collection } : c))
      );
      
      // Handle inventory updates based on status changes
      if (oldCollection && collection.status) {
        if (oldCollection.status !== "completed" && collection.status === "completed") {
          // Collection was marked as completed, update inventory
          updateJarInventory({
            cool: oldCollection.jarsReturned.cool || 0,
            pet: oldCollection.jarsReturned.pet || 0,
          });
          
          // Update customer's jars held
          await updateCustomerJars(oldCollection.customerId, oldCollection.jarsReturned, false);
        } else if (oldCollection.status === "completed" && collection.status !== "completed") {
          // Collection was uncompleted, revert inventory change
          updateJarInventory({
            cool: -oldCollection.jarsReturned.cool || 0,
            pet: -oldCollection.jarsReturned.pet || 0,
          });
          
          // Update customer's jars held (add back)
          await updateCustomerJars(oldCollection.customerId, oldCollection.jarsReturned, true);
        }
      }
    } catch (error: any) {
      console.error('Error updating collection:', error.message);
      toast({
        title: "Error updating collection",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const removeCollection = async (id: string) => {
    try {
      const collection = collections.find(c => c.id === id);
      if (!collection) throw new Error("Collection not found");
      
      const { error } = await supabase
        .from('collections')
        .delete()
        .eq('id', id);

      if (error) throw error;

      // Update local state
      setCollections((prev) => prev.filter((c) => c.id !== id));
      
      // If collection was completed, restore inventory
      if (collection && collection.status === "completed") {
        updateJarInventory({
          cool: -collection.jarsReturned.cool || 0,
          pet: -collection.jarsReturned.pet || 0,
        });
        
        // Update customer's jars held (add back)
        await updateCustomerJars(collection.customerId, collection.jarsReturned, true);
      }
    } catch (error: any) {
      console.error('Error removing collection:', error.message);
      toast({
        title: "Error removing collection",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Helper function to update customer's jars held
  const updateCustomerJars = async (
    customerId: string, 
    jars: { [productId: string]: number }, 
    isAdd: boolean
  ) => {
    try {
      // Get current customer data
      const { data: customerData, error: customerError } = await supabase
        .from('customers')
        .select('jars_held')
        .eq('id', customerId)
        .single();
      
      if (customerError) throw customerError;
      
      if (customerData) {
        const currentJarsHeld = customerData.jars_held as { [productId: string]: number };
        const updatedJarsHeld: { [productId: string]: number } = { ...currentJarsHeld };
        
        // Update jar counts
        Object.entries(jars).forEach(([productId, count]) => {
          const currentCount = updatedJarsHeld[productId] || 0;
          updatedJarsHeld[productId] = isAdd 
            ? currentCount + count 
            : Math.max(0, currentCount - count);
        });
        
        // Update customer in database
        const { error: updateError } = await supabase
          .from('customers')
          .update({
            jars_held: updatedJarsHeld,
            updated_at: new Date().toISOString()
          })
          .eq('id', customerId);
          
        if (updateError) throw updateError;
      }
    } catch (error: any) {
      console.error('Error updating customer jars:', error.message);
      toast({
        title: "Error updating customer jars",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return {
    collections,
    addCollection,
    updateCollection,
    removeCollection,
    loading
  };
}
