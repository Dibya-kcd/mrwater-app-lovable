
import { useState, useEffect } from "react";
import { Delivery } from "@/types";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export function useDeliveries(updateJarInventory: (jars: { cool: number; pet: number }) => void) {
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Fetch deliveries from Supabase
  useEffect(() => {
    const fetchDeliveries = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('deliveries')
          .select('*');

        if (error) {
          throw error;
        }

        if (data) {
          const formattedDeliveries: Delivery[] = data.map((delivery) => ({
            id: delivery.id,
            customerId: delivery.customer_id,
            date: delivery.date,
            jarsDelivered: delivery.jars_delivered as { [productId: string]: number },
            status: delivery.status as 'pending' | 'completed' | 'cancelled',
          }));

          setDeliveries(formattedDeliveries);
        }
      } catch (error: any) {
        console.error('Error fetching deliveries:', error.message);
        toast({
          title: "Error fetching deliveries",
          description: error.message,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchDeliveries();

    // Subscribe to changes in the deliveries table
    const subscription = supabase
      .channel('public:deliveries')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'deliveries' }, async () => {
        await fetchDeliveries();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [toast]);

  // Delivery management functions
  const addDelivery = async (delivery: Omit<Delivery, "id">) => {
    try {
      // Update Supabase
      const { data, error } = await supabase
        .from('deliveries')
        .insert([{
          customer_id: delivery.customerId,
          date: delivery.date,
          jars_delivered: delivery.jarsDelivered,
          status: delivery.status,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const newDelivery: Delivery = {
          id: data.id,
          customerId: data.customer_id,
          date: data.date,
          jarsDelivered: data.jars_delivered as { [productId: string]: number },
          status: data.status as 'pending' | 'completed' | 'cancelled',
        };

        setDeliveries((prev) => [...prev, newDelivery]);
      }
      
      // Update inventory only if delivery is completed
      if (delivery.status === "completed") {
        // Subtract from inventory
        updateJarInventory({
          cool: -delivery.jarsDelivered.cool || 0,
          pet: -delivery.jarsDelivered.pet || 0,
        });
        
        // Update customer's jars held
        await updateCustomerJars(delivery.customerId, delivery.jarsDelivered, true);
      }
    } catch (error: any) {
      console.error('Error adding delivery:', error.message);
      toast({
        title: "Error adding delivery",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const updateDelivery = async (id: string, delivery: Partial<Delivery>) => {
    try {
      const oldDelivery = deliveries.find(d => d.id === id);
      if (!oldDelivery) throw new Error("Delivery not found");
      
      // Convert from client model to database model
      const dbDelivery: any = {};
      if (delivery.customerId !== undefined) dbDelivery.customer_id = delivery.customerId;
      if (delivery.date !== undefined) dbDelivery.date = delivery.date;
      if (delivery.jarsDelivered !== undefined) dbDelivery.jars_delivered = delivery.jarsDelivered;
      if (delivery.status !== undefined) dbDelivery.status = delivery.status;
      dbDelivery.updated_at = new Date().toISOString();

      const { error } = await supabase
        .from('deliveries')
        .update(dbDelivery)
        .eq('id', id);

      if (error) throw error;

      // Update local state
      setDeliveries((prev) =>
        prev.map((d) => (d.id === id ? { ...d, ...delivery } : d))
      );
      
      // Handle inventory updates based on status changes
      if (oldDelivery && delivery.status) {
        if (oldDelivery.status !== "completed" && delivery.status === "completed") {
          // Delivery was marked as completed, update inventory
          updateJarInventory({
            cool: -oldDelivery.jarsDelivered.cool || 0,
            pet: -oldDelivery.jarsDelivered.pet || 0,
          });
          
          // Update customer's jars held
          await updateCustomerJars(oldDelivery.customerId, oldDelivery.jarsDelivered, true);
        } else if (oldDelivery.status === "completed" && delivery.status !== "completed") {
          // Delivery was uncompleted, revert inventory change
          updateJarInventory({
            cool: oldDelivery.jarsDelivered.cool || 0,
            pet: oldDelivery.jarsDelivered.pet || 0,
          });
          
          // Update customer's jars held (subtract)
          await updateCustomerJars(oldDelivery.customerId, oldDelivery.jarsDelivered, false);
        }
      }
    } catch (error: any) {
      console.error('Error updating delivery:', error.message);
      toast({
        title: "Error updating delivery",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const removeDelivery = async (id: string) => {
    try {
      const delivery = deliveries.find(d => d.id === id);
      if (!delivery) throw new Error("Delivery not found");
      
      const { error } = await supabase
        .from('deliveries')
        .delete()
        .eq('id', id);

      if (error) throw error;

      // Update local state
      setDeliveries((prev) => prev.filter((d) => d.id !== id));
      
      // If delivery was completed, restore inventory
      if (delivery && delivery.status === "completed") {
        updateJarInventory({
          cool: delivery.jarsDelivered.cool || 0,
          pet: delivery.jarsDelivered.pet || 0,
        });
        
        // Update customer's jars held (subtract)
        await updateCustomerJars(delivery.customerId, delivery.jarsDelivered, false);
      }
    } catch (error: any) {
      console.error('Error removing delivery:', error.message);
      toast({
        title: "Error removing delivery",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Helper function to update customer's jars held
  const updateCustomerJars = async (
    customerId: string, 
    jars: { [productId: string]: number }, 
    isAdd: boolean
  ) => {
    try {
      // Get current customer data
      const { data: customerData, error: customerError } = await supabase
        .from('customers')
        .select('jars_held')
        .eq('id', customerId)
        .single();
      
      if (customerError) throw customerError;
      
      if (customerData) {
        const currentJarsHeld = customerData.jars_held as { [productId: string]: number };
        const updatedJarsHeld: { [productId: string]: number } = { ...currentJarsHeld };
        
        // Update jar counts
        Object.entries(jars).forEach(([productId, count]) => {
          const currentCount = updatedJarsHeld[productId] || 0;
          updatedJarsHeld[productId] = isAdd 
            ? currentCount + count 
            : Math.max(0, currentCount - count);
        });
        
        // Update customer in database
        const { error: updateError } = await supabase
          .from('customers')
          .update({
            jars_held: updatedJarsHeld,
            updated_at: new Date().toISOString()
          })
          .eq('id', customerId);
          
        if (updateError) throw updateError;
      }
    } catch (error: any) {
      console.error('Error updating customer jars:', error.message);
      toast({
        title: "Error updating customer jars",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return {
    deliveries,
    addDelivery,
    updateDelivery,
    removeDelivery,
    loading
  };
}
