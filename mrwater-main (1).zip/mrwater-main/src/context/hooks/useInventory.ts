
import { useState, useEffect } from "react";
import { Inventory } from "@/types";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export function useInventory() {
  const [inventory, setInventory] = useState<Inventory>({ cool: 0, pet: 0 });
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Fetch inventory from Supabase
  useEffect(() => {
    const fetchInventory = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('inventory')
          .select('*')
          .eq('id', 'main')
          .maybeSingle();

        if (error) {
          throw error;
        }

        if (data) {
          setInventory({ cool: data.cool, pet: data.pet });
        } else {
          // Create initial inventory if none exists
          const { error: insertError } = await supabase
            .from('inventory')
            .insert([{ id: 'main', cool: 200, pet: 150 }]);

          if (insertError) throw insertError;

          setInventory({ cool: 200, pet: 150 });
        }
      } catch (error: any) {
        console.error('Error fetching inventory:', error.message);
        toast({
          title: "Error fetching inventory",
          description: error.message,
          variant: "destructive",
        });
        
        // Fallback to initial values if there's an error
        setInventory({ cool: 200, pet: 150 });
      } finally {
        setLoading(false);
      }
    };

    fetchInventory();
  }, [toast]);

  // Function to update jar inventory
  const updateJarInventory = async (jars: { cool: number; pet: number }) => {
    const updatedInventory = {
      cool: inventory.cool + jars.cool,
      pet: inventory.pet + jars.pet,
    };

    setInventory(updatedInventory);

    try {
      const { error } = await supabase
        .from('inventory')
        .update({ 
          cool: updatedInventory.cool, 
          pet: updatedInventory.pet,
          updated_at: new Date().toISOString()
        })
        .eq('id', 'main');

      if (error) throw error;
    } catch (error: any) {
      console.error('Error updating inventory:', error.message);
      toast({
        title: "Error updating inventory",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return {
    inventory,
    updateJarInventory,
    loading
  };
}
