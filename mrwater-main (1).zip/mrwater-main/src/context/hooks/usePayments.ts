
import { useState } from "react";
import { Payment } from "@/types";
import { initialPayments } from "../initialData";
import { generateId } from "../utils";

export function usePayments() {
  const [payments, setPayments] = useState<Payment[]>(initialPayments);

  // Payment management functions
  const addPayment = (payment: Omit<Payment, "id">) => {
    const newPayment = {
      ...payment,
      id: generateId(),
    };
    setPayments((prev) => [...prev, newPayment]);
  };

  const updatePayment = (id: string, payment: Partial<Payment>) => {
    setPayments((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...payment } : p))
    );
  };

  const removePayment = (id: string) => {
    setPayments((prev) => prev.filter((p) => p.id !== id));
  };

  return {
    payments,
    addPayment,
    updatePayment,
    removePayment,
  };
}
